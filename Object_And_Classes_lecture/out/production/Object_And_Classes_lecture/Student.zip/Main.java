import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner term = new Scanner(System.in);

        String input = term.nextLine();
        List<Student> students = new ArrayList<>();

        while (!"end".equals(input)){
            String[] data = input.split("\\s+");
            String firstName = data[0];
            String secondName = data[1];
            int age = Integer.parseInt(data[2]);
            String city = data[3];

            Student student = new Student(firstName,secondName,age, city);

            students.add(student);

            input = term.nextLine();
        }
        String studentCity = term.nextLine();

        for (Student student : students) {
            if (student.getCity().equals(studentCity)){
                System.out.printf("%s %s is %d years old%n", student.getFirstName(),
                        student.getSecondName(), student.getAge());
            }
        }
    }
}
